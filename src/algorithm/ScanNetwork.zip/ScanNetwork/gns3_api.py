import requests

GNS3_SERVER = "http://localhost:3080"
PROJECT_ID = "f0e92081-d288-4415-82f1-52984163e616"


def get_nodes():
    url = f"{GNS3_SERVER}/v2/projects/{PROJECT_ID}/nodes"
    res = requests.get(url)
    return res.json()


def build_node_map():
    nodes = get_nodes()

    mapping = {}

    for node in nodes:
        name = node["name"].split(".")[0].upper()

        console = node.get("console")
        host = node.get("console_host")

        if console and host:
            mapping[name] = {
                "host": host,
                "port": console
            }

    return mapping