import asyncio
from connection import connect
from cdp import extract_cdp_links
from lldp import extract_lldp_links
from utils import is_valid_link
from resolver import resolve

visited = set()
nodes = set()
links = []


# ================= SEND COMMAND =================
import asyncio

async def send_command(reader, writer, cmd):
    writer.write(cmd + "\n")

    output = ""

    for _ in range(10):
        await asyncio.sleep(0.5)

        try:
            data = await asyncio.wait_for(reader.read(1024), timeout=1)
            output += data
        except asyncio.TimeoutError:
            break

    return output

# ================= SCAN =================
async def scan(ip, conn_info):
    if ip in visited:
        return

    print(f"[+] Scanning {ip}")
    visited.add(ip)
    nodes.add(ip)

    print("DEBUG CONNECT:", conn_info)

    reader, writer = await connect(conn_info["host"], conn_info["port"])

    if not reader or not writer:
        return

    try:
        # 🔥 חשוב מאוד
        await send_command(reader, writer, "terminal length 0")

        # ================= CDP =================
        cdp_output = await send_command(reader, writer, "show cdp neighbors detail")
        print("CDP RAW:", repr(cdp_output))

        cdp_links = extract_cdp_links(cdp_output, ip)

        # ================= LLDP =================
        lldp_output = await send_command(reader, writer, "show lldp neighbors detail")
        #print("LLDP RAW:\n", repr(lldp_output))
        lldp_links = extract_lldp_links(lldp_output, ip)

        # ================= COMBINE =================
        all_links = cdp_links + lldp_links

        # ================= SAVE LINKS =================
        for link in all_links:
            if is_valid_link(link):
                links.append(link)

        # ================= RECURSION =================
        for link in all_links:
            target_ip = link.get("target")
            device_id = link.get("device_id")

            if not target_ip or target_ip == ip or target_ip in visited:
                continue

            print(f"[DISCOVER] {device_id} ({target_ip})")

            next_conn = resolve(device_id)

            if not next_conn:
                print(f"[!] No connection info for {device_id}")
                continue

            await scan(target_ip, next_conn)

    except Exception as e:
        print(f"[!] Error while scanning {ip}: {e}")

    finally:
        writer.close()
        await writer.wait_closed()


# ================= RUN =================
async def main():
    start_ip = "10.10.10.1"

    start_conn = {
        "host": "127.0.0.1",
        "port": 10056
    }

    await scan(start_ip, start_conn)

    print("\n🔥 NODES:")
    for n in nodes:
        print(n)

    print("\n🔗 LINKS:")
    for l in links:
        print(f"{l['source']} ({l['local_interface']}) --> {l['target']} ({l['remote_interface']})")


# ================= ENTRY =================
if __name__ == "__main__":
    asyncio.run(main())