import math
import random
import re
from typing import Any, Dict, List

class TopologyManager:
    @staticmethod
    def apply_force_layout(nodes, links, iterations=60, width=1000, height=800):
        for node in nodes:
            node['x'] = random.uniform(200, width - 200)
            node['y'] = random.uniform(200, height - 200)

        k = math.sqrt((width * height) / (len(nodes) or 1))
        t = width / 10  
        for _ in range(iterations):
            for i, v in enumerate(nodes):
                v['dx'], v['dy'] = 0, 0
                for j, u in enumerate(nodes):
                    if i == j: continue
                    dx, dy = v['x'] - u['x'], v['y'] - u['y']
                    dist = math.sqrt(dx*dx + dy*dy) + 0.1
                    v['dx'] += (dx/dist) * (k*k/dist)
                    v['dy'] += (dy/dist) * (k*k/dist)
            for l in links:
                try:
                    s = next(n for n in nodes if n['node_id'] == l['source'])
                    d = next(n for n in nodes if n['node_id'] == l['target'])
                    dx, dy = s['x'] - d['x'], s['y'] - d['y']
                    dist = math.sqrt(dx*dx + dy*dy) + 0.1
                    f = (dist*dist)/k
                    s['dx'] -= (dx/dist)*f; s['dy'] -= (dy/dist)*f
                    d['dx'] += (dx/dist)*f; d['dy'] += (dy/dist)*f
                except: continue
            for n in nodes:
                n['x'] += max(-t, min(t, n.get('dx', 0)))
                n['y'] += max(-t, min(t, n.get('dy', 0)))
                n['x'] = int(max(50, min(width-50, n['x'])))
                n['y'] = int(max(50, min(height-50, n['y'])))
            t *= 0.95

    @staticmethod
    def parse_port(p_str):
        m = re.search(r'(\d+)/(\d+)', p_str)
        if m: return int(m.group(1)), int(m.group(2))
        d = re.search(r'(\d+)', p_str)
        return 0, int(d.group(1)) if d else 0

    @classmethod
    def create_final_topology(cls, raw_nodes, raw_links):
        final_nodes = []
        final_conns = []
        for node in raw_nodes:
            name = node["name"].lower()
            nt = node["node_type"]
            # תיקון סיווג לפי שם
            if "esw" in name or "switch" in name: nt = "cisco_switch"
            
            device = {
                "node_id": node["node_id"], "name": node["name"], "modelType": "Cisco",
                "x": node["x"], "y": node["y"], "status": "stopped", "console": node["console"],
                "ports": [], "slot1": ""
            }
            if nt == "cisco_switch":
                device.update({"node_type": "qemu", "template_id": "96ff8c08-2f4c-4dc5-bfa6-79849810c400", "icon": "switch.png"})
            elif nt == "vpcs":
                device.update({"node_type": "vpcs", "template_id": "19021f99-e36f-394d-b4a1-8aaa902ab9cc", "icon": "pc.png"})
            else:
                device.update({"node_type": "dynamips", "template_id": "f5f30ee0-8e87-4cbf-8682-17e5aae51685", "icon": "router.png"})
            final_nodes.append(device)

        for l in raw_links:
            s_adp, s_prt = cls.parse_port(l["source_port"])
            t_adp, t_prt = cls.parse_port(l["target_port"])
            final_conns.append({
                "from": {"node_id": l["source"], "port_number": s_prt, "adapter_number": s_adp},
                "to": {"node_id": l["target"], "port_number": t_prt, "adapter_number": t_adp}
            })
            for n in final_nodes:
                if n["node_id"] == l["source"]:
                    n["ports"].append({"port_number": s_prt, "adapter_number": s_adp, "isTaken": True, "short_name": l["source_port"], "isOn": True})
        return final_nodes, final_conns