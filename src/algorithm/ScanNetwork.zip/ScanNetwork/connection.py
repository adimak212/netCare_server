import telnetlib3
import asyncio


async def connect(host, port):
    print(f"[TELNET3] {host}:{port}")

    reader, writer = await telnetlib3.open_connection(host, port)

    output = ""

    # 🔥 שלב 1 — להעיר את ה־console
    for _ in range(5):
        writer.write("\n")
        await asyncio.sleep(1)

        chunk = await reader.read(1024)
        output += chunk

        print("[INIT CHUNK]", repr(chunk))

        # 🔥 חכה עד שיש prompt אמיתי
        if ">" in output or "#" in output:
            break

    # 🔥 שלב 2 — enable אם צריך
    if ">" in output:
        writer.write("enable\n")
        await asyncio.sleep(1)

    # 🔥 שלב 3 — לבטל paging
    writer.write("terminal length 0\n")
    await asyncio.sleep(1)

    return reader, writer