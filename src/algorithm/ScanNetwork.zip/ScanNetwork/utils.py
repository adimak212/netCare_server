def normalize_device_id(device_id):
    if not device_id:
        return None

    # הסר domain
    device_id = device_id.split(".")[0]

    return device_id.upper()


def is_valid_link(link):
    # למנוע self loop
    if link["source"] == link["target"]:
        return False

    # למנוע IP ריק
    if not link["target"]:
        return False

    return True