from gns3_api import build_node_map

NODE_MAP = build_node_map()


def normalize(device_id):
    if not device_id:
        return None

    return device_id.split(".")[0].upper()


def resolve(device_id):
    device_id = normalize(device_id)

    conn = NODE_MAP.get(device_id)

    if not conn:
        print(f"[!] No mapping for {device_id}")
        return None

    return conn