import asyncio
import re
import telnetlib3
import ipaddress

class NetCareScanner:
    def __init__(self, username, password, network_cidr):
        self.username = username
        self.password = password
        self.visited_ips = set()
        self.infra_ips = set()
        self.all_arp_entries = {}       # IP -> {"mac": str, "parent": str}
        self.switches_mac_tables = {}   # Switch_IP -> {mac: port}
        self.devices_list = []
        self.links_list = []
        try:
            self.network = ipaddress.ip_network(network_cidr, strict=False)
        except:
            self.network = None

    def is_in_network(self, ip_str):
        if not self.network: return True
        try:
            return ipaddress.ip_address(ip_str) in self.network
        except:
            return False

    def clean_mac(self, mac_str):
        """מנרמל MAC לפורמט רציף וקטן (למשל: 005079666800)."""
        return re.sub(r'[^0-9a-fA-F]', '', mac_str).lower()

    async def capture_output(self, reader):
        """קורא פלט מה-Telnet עד לעצירה (Timeout)."""
        full_output = ""
        try:
            while True:
                chunk = await asyncio.wait_for(reader.read(4096), timeout=1.5)
                if not chunk: break
                full_output += chunk
        except asyncio.TimeoutError:
            pass
        return full_output

    def add_link(self, source_id, target_id, s_port, t_port):
        """מוסיף לינק לרשימה תוך מניעת כפילויות."""
        for link in self.links_list:
            if (link["source"] == source_id and link["target"] == target_id) or \
               (link["source"] == target_id and link["target"] == source_id):
                return
        self.links_list.append({
            "source": source_id, 
            "target": target_id,
            "source_port": s_port, 
            "target_port": t_port
        })

    async def scan_device(self, host, device_name="Unknown", capabilities_str=""):
        """סורק מכשיר בודד, מגלה שכנים (CDP) ומחשבים (ARP)."""
        if not self.is_in_network(host) or host in self.visited_ips:
            return

        self.visited_ips.add(host)
        self.infra_ips.add(host)

        try:
            # התחברות ב-Telnet
            reader, writer = await asyncio.wait_for(
                telnetlib3.open_connection(host, 23), timeout=5.0
            )

            async def send_cmd(cmd):
                writer.write(cmd + '\r\n')
                await writer.drain()
                await asyncio.sleep(0.4)

            # תהליך ההזדהות
            await send_cmd(self.username)
            await send_cmd(self.password)
            await send_cmd('terminal length 0')
            await self.capture_output(reader)

            # 1. גילוי תשתית - show cdp neighbors detail
            await send_cmd('show cdp neighbors detail')
            cdp_raw = await self.capture_output(reader)
            
            infra_to_scan = []
            blocks = cdp_raw.split('-------------------------')
            for block in blocks:
                n_ip = re.search(r'IP address: (\d{1,3}(?:\.\d{1,3}){3})', block)
                n_name = re.search(r'Device ID: (.*?)(?:\(|\s|\n)', block)
                n_cap = re.search(r'Capabilities:\s+(.*)', block, re.IGNORECASE)
                port_info = re.search(r'Interface: (.*?),.*?Port ID \(outgoing port\): (.*?)(?:\n|\r)', block, re.DOTALL)

                if n_ip and n_name and port_info:
                    nip = n_ip.group(1)
                    if self.is_in_network(nip):
                        self.add_link(host, nip, port_info.group(1).strip(), port_info.group(2).strip())
                        if nip not in self.visited_ips:
                            infra_to_scan.append({
                                "ip": nip, 
                                "name": n_name.group(1).strip(), 
                                "caps": n_cap.group(1) if n_cap else ""
                            })

            # 2. גילוי מחשבים - show ip arp
            await send_cmd('show ip arp')
            arp_raw = await self.capture_output(reader)
            arp_matches = re.findall(r'(\d{1,3}(?:\.\d{1,3}){3})\s+\d+\s+([0-9a-fA-F\.]{14})\s+ARPA', arp_raw)
            for ip_addr, mac_addr in arp_matches:
                if self.is_in_network(ip_addr) and ip_addr != host:
                    if ip_addr not in self.all_arp_entries:
                        self.all_arp_entries[ip_addr] = {"mac": self.clean_mac(mac_addr), "parent": host}

            # 3. קביעת סוג המכשיר (Router/Switch/PC)
            is_switch = False
            is_router = False
            
            if capabilities_str:
                caps = capabilities_str.upper()
                if 'S' in caps: is_switch = True
                if 'R' in caps: is_router = True

            # גיבוי - זיהוי לפי שם אם ה-Capabilities חסר
            name_lower = device_name.lower()
            if not is_switch and ("esw" in name_lower or "switch" in name_lower): is_switch = True
            if not is_router and ("router" in name_lower or "r1" in name_lower or "core" in name_lower): is_router = True

            node_type = "dynamips" if is_router else "cisco_switch" if is_switch else "vpcs"

            # 4. אם זה סוויץ' - שואבים טבלת MAC לצורך הצלבה
            if is_switch:
                await send_cmd('show mac address-table')
                mac_raw = await self.capture_output(reader)
                # Regex שתומך בכמה פורמטים של סיסקו (עם ובלי VLAN בהתחלה)
                mac_entries = re.findall(r'([0-9a-fA-F\.]{14})\s+\S+\s+\S+\s+(\S+)', mac_raw)
                if not mac_entries:
                    mac_entries = re.findall(r'\s+\d+\s+([0-9a-fA-F\.]{14})\s+\S+\s+(\S+)', mac_raw)
                
                self.switches_mac_tables[host] = {self.clean_mac(m[0]): m[1] for m in mac_entries}

            # הוספת המכשיר לרשימה הסופית
            self.devices_list.append({
                "node_id": host, 
                "name": device_name, 
                "node_type": node_type,
                "x": 0, "y": 0, "ports": [], "console": 23
            })
            
            writer.close()

            # רקורסיה: המשך סריקה לשכנים שהתגלו
            for neighbor in infra_to_scan:
                await self.scan_device(neighbor["ip"], neighbor["name"], neighbor["caps"])
        
        except Exception:
            # במקרה של כשל בחיבור למכשיר מסוים, נמשיך הלאה
            pass

    def finalize_pcs(self):
        """עוברת על כל ה-ARP שמצאנו ומחברת מחשבים למי שבאמת רואה את ה-MAC שלהם."""
        for ip, info in self.all_arp_entries.items():
            # אם ה-IP כבר מזוהה כתשתית (סוויץ'/ראוטר), מדלגים
            if ip in self.infra_ips: continue 
            
            target_mac = info["mac"]
            actual_parent = info["parent"] 
            actual_port = "Fa0/0"
            
            # בדיקה האם המחשב יושב מאחורי אחד הסוויצ'ים שסרקנו
            for sw_ip, mac_table in self.switches_mac_tables.items():
                if target_mac in mac_table:
                    # מצאנו את הסוויץ' שאליו המחשב באמת מחובר
                    actual_parent = sw_ip
                    actual_port = mac_table[target_mac]
                    break
            
            # הוספת המחשב כ-VPCS
            self.devices_list.append({
                "node_id": ip, 
                "name": f"PC_{ip.split('.')[-1]}", 
                "node_type": "vpcs",
                "x": 0, "y": 0, "ports": [], "console": 0
            })
            # חיבור המחשב לפורט הנכון בסוויץ' (או לראוטר אם לא נמצא סוויץ')
            self.add_link(actual_parent, ip, actual_port, "eth0")
            self.infra_ips.add(ip)