def extract_lldp_links(output, source_ip):
    links = []
    current = {}

    for line in output.splitlines():
        line = line.strip()

        # ================= System Name =================
        if "System Name" in line:
            parts = line.split(":", 1)
            if len(parts) < 2:
                continue

            current["device_id"] = parts[1].strip()

        # ================= Management IP =================
        elif "Management Address" in line:
            parts = line.split(":", 1)
            if len(parts) < 2:
                continue

            current["ip"] = parts[1].strip()

        # ================= Local Port =================
        elif "Local Port" in line:
            parts = line.split(":", 1)
            if len(parts) < 2:
                continue

            current["local_interface"] = parts[1].strip()

        # ================= Remote Port =================
        elif "Port id" in line:
            parts = line.split(":", 1)
            if len(parts) < 2:
                continue

            current["remote_interface"] = parts[1].strip()

            # 🔥 רק אם יש IP — ניצור link
            if "ip" in current:
                links.append({
                    "source": source_ip,
                    "target": current.get("ip"),
                    "local_interface": current.get("local_interface"),
                    "remote_interface": current.get("remote_interface"),
                    "device_id": current.get("device_id")
                })

                # 🔥 איפוס כדי לא לערבב devices
                current = {}

    return links