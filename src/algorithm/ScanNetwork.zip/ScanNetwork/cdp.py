def extract_cdp_links(output, source_ip):
    links = []
    current = {}

    for line in output.splitlines():
        line = line.strip()

        # ================= Device ID =================
        if "Device ID" in line:
            parts = line.split(":", 1)
            if len(parts) < 2:
                continue

            current = {
                "device_id": parts[1].strip()
            }

        # ================= IP Address =================
        elif "IP address" in line:
            parts = line.split(":", 1)
            if len(parts) < 2:
                continue

            current["ip"] = parts[1].strip()

        # ================= Interfaces =================
        elif "Interface" in line and "Port ID" in line:
            parts = line.split(",")

            if len(parts) < 2:
                continue

            # local interface
            local_parts = parts[0].split(":", 1)
            remote_parts = parts[1].split(":", 1)

            if len(local_parts) < 2 or len(remote_parts) < 2:
                continue

            local_int = local_parts[1].strip()
            remote_int = remote_parts[1].strip()

            # רק אם יש IP
            device_id = current.get("device_id") or current.get("ip")

            links.append({
                "source": source_ip,
                "target": current.get("ip"),
                "local_interface": local_int,
                "remote_interface": remote_int,
                "device_id": device_id
            })

            current = {}

    return links