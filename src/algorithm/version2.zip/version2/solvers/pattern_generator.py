from __future__ import annotations

from typing import Dict, List

from src.algorithm.version2.domain.pattern import Pattern
from src.algorithm.version2.domain.demand_vector import DemandVector
from src.algorithm.version2.domain.resources import Resources


class PatternGenerator:

    def __init__(self, templates: Dict[str, Resources], bin_templates: Dict[str, Dict]):
        self.templates = templates
        self.bin_templates = bin_templates

    def generate_for_bin_type(self, bin_type: str) -> List[Pattern]:

        rack = self.bin_templates[bin_type]

        rack_resources = Resources(
            u=rack["u"],
            watt=rack["watt"],
            cost=rack["cost"],
            ports=rack["ports"]
        )

        patterns: List[Pattern] = []

        # limits per item
        max_pc = rack_resources.u // self.templates["pc"].u
        max_switch = rack_resources.u // self.templates["switch"].u
        max_router = rack_resources.u // self.templates["router"].u
        max_controller = 0

        if "controller" in self.templates:
            max_controller = rack_resources.u // self.templates["controller"].u

        for pc in range(max_pc + 1):
            for sw in range(max_switch + 1):
                for rt in range(max_router + 1):
                    for ctrl in range(max_controller + 1):

                        if pc == sw == rt == ctrl == 0:
                            continue

                        counts = DemandVector(
                            pc=pc,
                            switch=sw,
                            router=rt,
                            controller=ctrl
                        )

                        resources = self._compute_resources(counts)

                        if not resources.fits_in(rack_resources):
                            continue

                        patterns.append(
                            Pattern(
                                bin_type=bin_type,
                                counts=counts,
                                total_resources=resources
                            )
                        )

        patterns = self._prune_patterns(patterns)

        patterns.sort(
            key=lambda p: self._pattern_score(p, rack_resources),
            reverse=True
        )

        return patterns

    def _compute_resources(self, counts: DemandVector) -> Resources:

        r = Resources()

        r += self.templates["pc"] * counts.pc
        r += self.templates["switch"] * counts.switch
        r += self.templates["router"] * counts.router

        if counts.controller and "controller" in self.templates:
            r += self.templates["controller"] * counts.controller

        return r

    def _pattern_score(self, pattern: Pattern, rack: Resources) -> float:

        r = pattern.total_resources

        utilization = (
            r.u / rack.u +
            r.watt / rack.watt
        ) / 2

        coverage = pattern.counts.total_items()

        return utilization + coverage

    def _prune_patterns(self, patterns: List[Pattern]) -> List[Pattern]:

        unique = {}

        for p in patterns:
            sig = p.signature()

            if sig not in unique:
                unique[sig] = p
            else:
                if p.total_items() > unique[sig].total_items():
                    unique[sig] = p

        return list(unique.values())