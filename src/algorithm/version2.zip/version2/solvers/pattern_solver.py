from __future__ import annotations
from typing import List

from src.algorithm.version2.domain.demand_vector import DemandVector
from src.algorithm.version2.domain.pattern_solver_result import PatternSolveResult


class PatternSolver:
    """
    Greedy O(P) solver using pattern multiplicity.

    Assumption:
    patterns are already pre-sorted offline by desirability / density / efficiency.
    Then solve() does one linear pass over patterns.
    """

    def __init__(self, patterns: List):
        self.patterns = patterns

    def solve(self, demand: DemandVector) -> PatternSolveResult:
        remaining = DemandVector(
            pc=demand.pc,
            switch=demand.switch,
            router=demand.router,
            controller=demand.controller,
        )

        provided = DemandVector(pc=0, switch=0, router=0, controller=0)

        rack_count = 0
        pattern_usage: list[dict] = []

        for pattern in self.patterns:
            if remaining.is_zero():
                break

            multiplicity = self._compute_multiplicity(pattern.counts, remaining)

            if multiplicity <= 0:
                continue

            used_counts = pattern.counts.scale(multiplicity)

            provided = provided + used_counts
            remaining = (remaining - used_counts).clamp_non_negative()
            rack_count += multiplicity

            pattern_usage.append({
                "pattern": pattern.signature(),
                "count": multiplicity,
                "counts": pattern.counts.as_dict(),
            })

        waste = DemandVector(
            pc=max(provided.pc - demand.pc, 0),
            switch=max(provided.switch - demand.switch, 0),
            router=max(provided.router - demand.router, 0),
            controller=max(provided.controller - demand.controller, 0),
        )

        waste_score = waste.total_items()

        return PatternSolveResult(
            rack_count=rack_count,
            waste_score=waste_score,
            remaining=remaining,
            pattern_usage=pattern_usage,
        )
    def _compute_multiplicity(self, pattern_counts: DemandVector, remaining: DemandVector) -> int:
        """
        Compute how many times this pattern can be used in one shot.

        Strategy:
        - For each positive dimension in the pattern, compute floor(remaining / pattern)
        - Take the minimum positive bound
        - If no full fit exists but the pattern still covers something useful, return 1
        - If it covers nothing useful, return 0

        This keeps solve() linear in number of patterns.
        """
        bounds = []

        if pattern_counts.pc > 0 and remaining.pc > 0:
            bounds.append(remaining.pc // pattern_counts.pc)

        if pattern_counts.switch > 0 and remaining.switch > 0:
            bounds.append(remaining.switch // pattern_counts.switch)

        if pattern_counts.router > 0 and remaining.router > 0:
            bounds.append(remaining.router // pattern_counts.router)

        if pattern_counts.controller > 0 and remaining.controller > 0:
            bounds.append(remaining.controller // pattern_counts.controller)

        if bounds:
            m = min(bounds)
            if m > 0:
                return m

        # fallback: if this pattern still helps at least one remaining dimension,
        # allow taking it once
        if self._has_useful_coverage(pattern_counts, remaining):
            return 1

        return 0

    def _has_useful_coverage(self, pattern_counts: DemandVector, remaining: DemandVector) -> bool:
        return (
            (pattern_counts.pc > 0 and remaining.pc > 0) or
            (pattern_counts.switch > 0 and remaining.switch > 0) or
            (pattern_counts.router > 0 and remaining.router > 0) or
            (pattern_counts.controller > 0 and remaining.controller > 0)
        )