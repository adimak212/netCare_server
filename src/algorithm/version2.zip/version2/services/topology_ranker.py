from __future__ import annotations
from typing import List
from src.algorithm.version2.services.topology_cache import TopologyCache
from src.algorithm.version2.solvers.pattern_solver import PatternSolver
from src.algorithm.version2.services.topology_evaluator import TopologyEvaluator
from src.algorithm.version2.topologies.base import TopologyBase

class TopologyRanker:
    def __init__(self, topologies, pattern_solver: PatternSolver, evaluator: TopologyEvaluator):
        self.topologies = topologies
        self.pattern_solver = pattern_solver
        self.evaluator = evaluator
        self.cache = TopologyCache()

    def evaluate_topology(self, topology: TopologyBase, params, preferences, unit_costs):

        pcs = int(params["pcs"])

        cached = self.cache.get(topology.key, pcs)

        if cached is None:
            normalized = topology.normalize(params)
            demand = topology.to_pattern_demand(normalized)
            packing = self.pattern_solver.solve(demand)
            cached = {
                "normalized": normalized,
                "demand": demand,
                "packing": packing,
            }

            self.cache.set(topology.key, pcs, cached)

        normalized = cached["normalized"]
        demand = cached["demand"]
        packing = cached["packing"]
        evaluation = self.evaluator.evaluate(
            topology_key=topology.key,
            topology_name= topology.name,
            demand=demand,
            preferences=preferences,
            topology_metrics=topology.metrics(),
            unit_costs=unit_costs,
            rack_count=packing.rack_count,
            waste_score=packing.waste_score,
        )

        return {"evaluation" : evaluation , "normalized" : normalized}

    def rank(self, params, preferences, unit_costs):

        results = []

        for topology in self.topologies:
            result = self.evaluate_topology(
                topology,
                params,
                preferences,
                unit_costs,
            )
            results.append(result)

        results.sort(key=lambda r: r["evaluation"].final_score, reverse=True)

        return results