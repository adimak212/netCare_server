from __future__ import annotations
from dataclasses import dataclass
from .demand_vector import DemandVector
from .resources import Resources


@dataclass(frozen=True, slots=True)
class Pattern:
    bin_type: str
    counts: DemandVector
    total_resources: Resources

    def total_items(self) -> int:
        return self.counts.total_items()

    def signature(self) -> str:
        c = self.counts
        return f"{self.bin_type}|pc={c.pc}|sw={c.switch}|rt={c.router}|ctrl={c.controller}"

    def as_dict(self) -> dict:
        return {
            "bin_type": self.bin_type,
            "counts": self.counts.as_dict(),
            "total_resources": self.total_resources.as_dict(),
        }