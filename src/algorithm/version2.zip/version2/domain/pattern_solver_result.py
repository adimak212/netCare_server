from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

from .demand_vector import DemandVector


@dataclass(slots=True)
class PatternSolveResult:
    rack_count: int
    waste_score: float
    remaining: DemandVector
    pattern_usage: list[dict[str, Any]] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "rack_count": self.rack_count,
            "waste_score": self.waste_score,
            "remaining": self.remaining.as_dict(),
            "pattern_usage": self.pattern_usage,
        }